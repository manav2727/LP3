//Assignemnt 1
//Write a non-recursive and recursive program to calculate Fibonacci
//numbers and analyze their time and space complexity.

#include<bits/stdc++.h>

using namespace std;

//Iteratively
void fib(int num) {
   int x = 0, y = 1, z = 0;
   for (int i = 0; i < num+1; i++) {
      cout << x << " ";
      z = x + y;
      x = y;
      y = z;
   }
}

int rSteps = 0;

//Recursively
int rStepFibbonacci(int n){
    rSteps++;
    if(n==0){
        return 0;
    }
    if(n==1){
        return 1;
    }
    if(n==2){
        return 1;
    }
    return rStepFibbonacci(n-1)+rStepFibbonacci(n-2);
}

int main(){
    int n;
    cout<<"Enter no : ";
    cin >> n;
    cout<<"-------ITERATIVELY-------"<<endl;
    cout << "The fibonacci series : ", fib(n);
    cout<<endl;
    cout<<"-------RECURSIVELY-------"<<endl;
    cout << "Fibbonacci Value : " << rStepFibbonacci(n) << '\n';
    cout << "Steps required using recursion : " << rSteps << '\n';
    return 0;
}

/*
Recursive fibbonacci:
Time Complexity: O(n*2n)
Auxiliary Space: O(n), For recursion call stack.

Iterative fibbonacci:
Time Complexity: O(n) 
Auxiliary Space: O(1)
*/