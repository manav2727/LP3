// MINI PROJECT
// Implement the Naive string matching algorithm and Rabin-Karp algorithm for
// string matching. Observe difference in working of both the algorithms for the same input.

#include <bits/stdc++.h>

using namespace std;

void naive_search(const string &text, const string &pattern)
{
    int n = text.length();
    int m = pattern.length();

    for (int i = 0; i <= n - m; i++)
    {
        int j;
        for (j = 0; j < m; j++)
        {
            if (text[i + j] != pattern[j])
            {
                break;
            }
        }
        if (j == m)
        {
            cout << "Pattern found at index " << i << endl;
        }
    }
}

const int d = 256; // number of characters in input alphabet
const int q = 101; // A prime number for modulus

void rabin_karp_search(const string &text, const string &pattern)
{
    int n = text.length();
    int m = pattern.length();
    int p = 0; // hash value for pattern
    int t = 0; // hash value for text
    int h = 1;

    // Calculate h = d^(m-1) % q
    for (int i = 0; i < m - 1; i++)
    {
        h = (h * d) % q;
    }

    // Calculate hash value for pattern and first window of text
    for (int i = 0; i < m; i++)
    {
        p = (d * p + pattern[i]) % q;
        t = (d * t + text[i]) % q;
    }

    for (int i = 0; i <= n - m; i++)
    {
        if (p == t)
        {
            int j;
            for (j = 0; j < m; j++)
            {
                if (text[i + j] != pattern[j])
                {
                    break;
                }
            }
            if (j == m)
            {
                cout << "Pattern found at index " << i << endl;
            }
        }

        if (i < n - m)
        {
            t = (d * (t - text[i] * h) + text[i + m]) % q;
            if (t < 0)
            {
                t += q;
            }
        }
    }
}

int main()
{
    string text = "ABCCBADEEABCABC";
    string pattern = "ABC";

    cout << "Naive Search Results: " << endl;
    naive_search(text, pattern);

    cout << "\nRabin-Karp Search Results: " << endl;
    rabin_karp_search(text, pattern);

    return 0;
}

/*
Difference in Working:
Naive Algorithm: This algorithm checks for the pattern explicitly by comparing the text and pattern character by character.

Rabin-Karp Algorithm: This algorithm uses hashing to identify potential matches, so it can skip many comparisons if the hash values don't match. When the hash values do match, only then does it revert to explicit character-by-character checking to confirm a match.

For the provided example, both will yield similar results. However, the key difference lies in the underlying operations. The naive algorithm may need more character comparisons, especially for longer texts with many almost-matches. Rabin-Karp can be more efficient in these cases due to its hash-based comparisons, but hash collisions can affect its performance.
*/